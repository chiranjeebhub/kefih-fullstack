@extends('admin.layouts.app_new')
@section('pageTitle',$page_details['Title'])
@section('boxTitle',$page_details['Box_Title'])
@section('content')
	
<style>
[type="radio"]:checked, [type="radio"]:not(:checked) {
	position: relative !important;
	left: 0 !important;
	opacity: 4 !important;
}
</style>
<?php 
		$parameters = Request::segment(3);				
?>
	
<div class="">
	<div class="allbutntbl">
		<a href="{{ route('adddocket') }}" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add Docket</a>
	</div>

</div>

		<!--<table class="allbutntbl">
		<tr>
		<td><a href="{{ route('addbrand') }}" class="btn btn-success"><i class="fa fa-plus" aria-hidden="true"></i> Add Brand</a></td>
		<td><button type="button" class="btn btn-danger btnSubmitTrigger" disabled>Bulk Delete</button></td>
		<td><input type="text" name="search_string" class="form-control search_string" placeholder="Search" value="{{$parameters}}"></td>
		<td></td>
		<td><button type="submit" class="btn btn-default reset" >Reset</button></td>

		</tr>
		</table>-->
		


				<div class="table-responsive">
				  <table id="example1" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>Docket Type</th>
							<th>Docket Number</th>
							<th>Status</th>

						</tr>
					</thead>
					<tbody>
					
					  @foreach($dockets as $docket)

						<tr>
				            <td>{{$docket->docket_type}}</td>
							<td>{!!$docket->docket_number!!}</td>
						    <td>
						    	@if($docket->status ==0)         
								<i class="fa fa-close text-red" aria-hidden="true"></i> 
								@else
								<i class="fa fa-check text-green" aria-hidden="true"></i>  
								@endif
						    </td>
						</tr>
					    @endforeach
					</tbody>
					
				  </table>
				</div>
				
			
				
				 
@endsection
