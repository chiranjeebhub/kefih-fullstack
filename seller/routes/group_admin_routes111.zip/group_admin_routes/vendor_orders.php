<?php

Route::group(['prefix' => 'admin','middleware' => ['auth:vendor' or 'auth']], function () {
    
Route::get('/vendor_orders/{type}', 'sws_Admin\VendorOrderController@index')->name('vendor_orders');
Route::any('/vendor_order_search/{type}/{str}/{daterange}/{vendor}/{brand}/{category}', 'sws_Admin\VendorOrderController@index')->name('vendor_order_search_all');


Route::get('vendor_all_orders', 'sws_Admin\VendorOrderController@vendor_all_sorders')->name('vendor_all_orders');
Route::any('/vendor_all_sorders_filter/{str}/{daterange}/{vendor}/{brand}/{category}', 'sws_Admin\VendorOrderController@vendor_all_sorders')->name('vendor_all_sorders_filter');

Route::get('vendor_all_orders_export', 'sws_Admin\VendorOrderController@vendor_all_orders_export')->name('vendor_all_orders_export');
Route::get('/vendor_all_orders_export_filter/{str}/{daterange}/{vendor}/{brand}/{category}','sws_Admin\VendorOrderController@vendor_all_orders_export')->name('vendor_all_orders_export_filter');


Route::get('/pickupOrder/{id}', 'sws_Admin\VendorOrderController@pickupOrder')->name('pickupOrder');
Route::get('/packageReceived/{id}', 'sws_Admin\VendorOrderController@packageReceived')->name('packageReceived');

Route::get('/refundConfirm/{id}', 'sws_Admin\VendorOrderController@refundConfirm')->name('refundConfirm');
Route::get('/replaceConfirm/{id}', 'sws_Admin\VendorOrderController@replaceConfirm')->name('replaceConfirm');

// Route::any('/vendor_order_search/{type}/{str}', 'sws_Admin\VendorOrderController@vendor_order_search')->name('vendor_order_search');


Route::get('/vendor_orders_export/{type}', 'sws_Admin\VendorOrderController@vendor_orders_export')->name('vendor_orders_export');
Route::get('/vendor_orders_export_search/{type}/{str}/{daterange}/{vendor}/{brand}/{category}', 'sws_Admin\VendorOrderController@vendor_orders_export')->name('vendor_orders_export_search');

Route::get('/vendor_order_detail/{order_detail_id}','sws_Admin\VendorOrderController@orderdetail')->name('vendor_order_detail');
Route::get('/vendor_order_generate_invoice/{order_detail_id}', 'sws_Admin\VendorOrderController@vendor_order_generate_invoice')->name('vendor_order_generate_invoice');
Route::get('/vendor_order_print_invoice/{order_detail_id}', 'sws_Admin\VendorOrderController@vendor_order_print_invoice')->name('vendor_order_print_invoice');
Route::get('/vendor_order_invoice/{order_detail_id}', 'sws_Admin\VendorOrderController@vendor_order_invoice')->name('vendor_order_invoice');
Route::any('/vendor_order_shipping/{order_detail_id}', 'sws_Admin\VendorOrderController@vendor_order_shipping')->name('vendor_order_shipping');
Route::get('/vendor_order_delivered/{order_detail_id}', 'sws_Admin\VendorOrderController@vendor_order_delivered')->name('vendor_order_delivered'); 
Route::get('/vendor_order_track/{order_detail_id}', 'sws_Admin\VendorOrderController@vendor_order_track')->name('vendor_order_track'); 
Route::any('/vendor_order_shipping_extradetails/{order_detail_id}', 'sws_Admin\VendorOrderController@vendor_order_shipping_extradetails')->name('vendor_order_shipping_extradetails');

});
