 Thank you for shopping at Redlips. We are prepping your
Bag of Joy. We will deliver your order ending with {{substr($data['order_no'], -5)}} by {{Date('d M Y', strtotime("+7 days"))}}.
Stay Stylish!
