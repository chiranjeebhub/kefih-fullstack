{{$data['otp']}} is your redlips.com OTP and is valid for 10 minutes
