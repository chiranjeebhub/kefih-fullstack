<table id="example1" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th>Sr. No.</th>
							<th>Vendor Name</th>
							<th>GST No.</th>
							<th>Sale Amt</th>
							<th>Commission Amt</th>
							<th>Net Amt</th>
							<th>Paid Amt</th>
							<th>Balance Amt</th>
							<th>IGST Amt</th>
							<th>CGST Amt</th>
							<th>SGST Amt</th>
						</tr>
					</thead>
					<tbody>
					<?php $i=1;  ?>
					  @foreach($ledgers as $row)
					  <?php
							$igst=App\Http\Controllers\sws_Admin\LedgerController::tax_type($row->id,1,'','');
							$cgst_sgst=App\Http\Controllers\sws_Admin\LedgerController::tax_type($row->id,2,'','');
					  ?>
					 	<tr>
							<td>{{$i++}}</td>
							<td>{{$row->public_name}}</td>
							<td>{{$row->gst_no}}</td>
							<td>{{$row->total_product_amt}}</td>
							<td>{{round($row->total_commission_amt)}}</td>
							<td>{{round($row->total_product_amt-$row->total_commission_amt)}}</td>
							<td></td>
							<td></td>
							<td><?php echo number_format((@$igst->order_detail_tax_amt),2);?></td>
							<td><?php echo number_format((@$cgst_sgst->order_detail_tax_amt/2),2);?></td>
							<td><?php echo number_format((@$cgst_sgst->order_detail_tax_amt/2),2);?></td>
							
						</tr>
					    @endforeach
					</tbody>
				  </table>